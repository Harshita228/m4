package testng;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserScript {
	WebDriver driver;


	@BeforeTest
	@Parameters("browser")
	public void setupTest(String browser) throws Exception
	{
		//Verify if parameter passed from TestNG is FireFox
//		if(browser.equalsIgnoreCase("firefox")) {
//			//Proxy and version setting
//			System.setProperty("webdriver.firefox.bin","C:\\Users\\kartikks\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
//			FirefoxProfile profile = new FirefoxProfile();
//			profile.setPreference("newtwork.proxy.type",1);
//			profile.setPreference("newtwork.proxy.http","chnproxy.igate.com");
//			profile.setPreference("newtwork.proxy.http_port",8080);
//			profile.setPreference("network.proxy.ssl", "chnproxy.igate.com");
//			profile.setPreference("network.proxy.ssl_port", 8080);
//			driver=new FirefoxDriver(profile);
//		}		
//		//Verify if parameter passed from TestNG is Chrome
//		else 
			if(browser.equalsIgnoreCase("chrome"))	{
			//set path to chromedriver.exe
			System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
			//create Chrome instance
			driver = new ChromeDriver();
			
		}
		//Verify if parameter passed from TestNG is IE
		else if(browser.equalsIgnoreCase("ie"))	{
			// FOR IE BROWSER	
			System.setProperty("webdriver.ie.driver","D:\\IEDriverServer.exe");
			DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
			cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			driver = new InternetExplorerDriver(cap);
		}
		else{
			//If no browser passed throw exception
			throw new Exception("No browser specified");
		}

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void RunCrossBrowserScript() throws InterruptedException 
	{
		driver.get("http://www.google.com/");	
		System.out.println(driver.getTitle());
	}
}